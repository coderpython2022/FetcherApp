new TypeIt(".text-description", {
    strings: ["This is a great string.", "But here is a better one."],
    speed: 50,
    waitUntilVisible: true,
}).go();